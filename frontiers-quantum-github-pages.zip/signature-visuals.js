/* Accessible, deferred playback handling for the cinematic homepage hero video. */
(() => {
  'use strict';
  const video = document.querySelector('.hero-video');
  if (!video) return;

  const source = video.querySelector('source[data-src]');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const saveData = Boolean(navigator.connection && navigator.connection.saveData);
  let loaded = false;

  const pauseForMotionPreference = () => {
    if (reducedMotion.matches) {
      video.pause();
      video.removeAttribute('autoplay');
      try { video.currentTime = 0; } catch (_) { /* Metadata may not be ready. */ }
    }
  };
  pauseForMotionPreference();
  reducedMotion.addEventListener?.('change', pauseForMotionPreference);

  const loadVideo = () => {
    if (loaded || !source || reducedMotion.matches || saveData || document.hidden) return;
    loaded = true;
    source.src = source.dataset.src;
    source.removeAttribute('data-src');
    video.load();
    video.play().catch(() => { /* Poster remains the visual fallback. */ });
  };

  const scheduleVideo = () => {
    if (reducedMotion.matches || saveData) return;
    if ('requestIdleCallback' in window) window.requestIdleCallback(loadVideo, { timeout: 3500 });
    else window.setTimeout(loadVideo, 1200);
  };

  if (document.readyState === 'complete') scheduleVideo();
  else window.addEventListener('load', scheduleVideo, { once: true });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) video.pause();
    else if (!reducedMotion.matches && !saveData) {
      if (!loaded) loadVideo();
      else video.play().catch(() => {});
    }
  });

  video.addEventListener('error', () => {
    video.style.opacity = '0';
  }, { once: true });
})();
