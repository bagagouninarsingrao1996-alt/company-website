(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  // Mobile navigation: keyboard-operable, stateful and closed after route changes.
  const menuToggle = $('#menuToggle');
  const primaryNav = $('#primaryNav');
  const closeMenu = () => {
    if (!menuToggle || !primaryNav) return;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation');
    primaryNav.classList.remove('mobile-open');
  };
  if (menuToggle && primaryNav) {
    menuToggle.addEventListener('click', () => {
      const open = menuToggle.getAttribute('aria-expanded') !== 'true';
      menuToggle.setAttribute('aria-expanded', String(open));
      menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      primaryNav.classList.toggle('mobile-open', open);
    });
    $$('#primaryNav a').forEach((link) => link.addEventListener('click', closeMenu));
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeMenu();
    });
    document.addEventListener('click', (event) => {
      if (!event.target.closest('.site-header')) closeMenu();
    });
  }

  // B2B / B2C / D2C panel. Works on the homepage and the dedicated solutions page.
  const modelContent = {
    b2b: {
      eyebrow: 'BUSINESS-TO-BUSINESS', icon: '▥', title: 'Make every business relationship work harder.',
      description: 'Build a digital ecosystem for business buyers, channel partners and internal teams—with fewer manual steps and clearer visibility from enquiry to fulfilment.',
      chips: ['Partner portals', 'CRM & lead workflows', 'Orders & invoicing', 'ERP integration']
    },
    b2c: {
      eyebrow: 'BUSINESS-TO-CONSUMER', icon: '⌂', title: 'Make every customer interaction count.',
      description: 'Create simple, connected customer journeys—from discovery and purchase to support—with intuitive experiences across the touchpoints people use every day.',
      chips: ['Customer-facing websites', 'E-commerce journeys', 'Payments & billing', 'Service & support']
    },
    d2c: {
      eyebrow: 'DIRECT-TO-CONSUMER', icon: '↗', title: 'Build a direct connection with your audience.',
      description: 'Give your brand the digital foundation to own customer relationships, learn from first-party insights and manage the journey from storefront to fulfilment.',
      chips: ['Branded storefronts', 'Customer data workflows', 'Subscriptions & payments', 'Order operations']
    }
  };
  const modelTabs = $$('.model-tab');
  const modelPanel = $('#modelPanel');
  function activateModel(key) {
    const content = modelContent[key];
    if (!content || !modelPanel) return;
    modelTabs.forEach((tab) => {
      const active = tab.dataset.model === key;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
    });
    modelPanel.setAttribute('aria-labelledby', `tab-${key}`);
    const eyebrow = $('#modelEyebrow');
    const icon = $('#modelIcon');
    const title = $('#modelTitle');
    const description = $('#modelDescription');
    const chips = $('#modelChips');
    if (eyebrow) eyebrow.textContent = content.eyebrow;
    if (icon) icon.textContent = content.icon;
    if (title) title.textContent = content.title;
    if (description) description.textContent = content.description;
    if (chips) {
      chips.replaceChildren(...content.chips.map((label) => {
        const chip = document.createElement('span');
        chip.textContent = label;
        return chip;
      }));
    }
  }
  modelTabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activateModel(tab.dataset.model));
    tab.addEventListener('keydown', (event) => {
      if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      let next = index;
      if (event.key === 'ArrowRight') next = (index + 1) % modelTabs.length;
      if (event.key === 'ArrowLeft') next = (index - 1 + modelTabs.length) % modelTabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = modelTabs.length - 1;
      modelTabs[next].focus();
      activateModel(modelTabs[next].dataset.model);
    });
  });
  if (modelTabs.length) activateModel('b2b');

  // Link-to-form intent prefill. Query strings can request a topic without changing the form markup.
  const interestSelect = $('#interestSelect');
  const enquiryType = $('#enquiryType');
  const params = new URLSearchParams(window.location.search);
  const requestedInterest = params.get('interest');
  const requestedType = params.get('type');
  if (interestSelect && requestedInterest) {
    const desired = requestedInterest.replace(/\+/g, ' ');
    const option = Array.from(interestSelect.options).find((item) => item.value.toLowerCase() === desired.toLowerCase() || item.text.toLowerCase() === desired.toLowerCase());
    if (option) interestSelect.value = option.value;
    else if (desired.toLowerCase().includes('b2b')) interestSelect.value = 'B2B / B2C / D2C platforms';
    else if (desired.toLowerCase().includes('digital business')) interestSelect.value = 'Digital Business & Commerce';
    else if (desired.toLowerCase().includes('ai')) interestSelect.value = 'AI & Research';
  }
  if (enquiryType && requestedType) {
    const type = requestedType.toLowerCase();
    if (type.includes('partner')) enquiryType.value = 'Partnership';
    else if (type.includes('career')) enquiryType.value = 'Careers';
    else if (type.includes('research')) enquiryType.value = 'Research';
  }
  // Also prefill when a card links from an in-page section to the existing home form.
  $$('[data-interest]').forEach((link) => {
    link.addEventListener('click', () => {
      if (!interestSelect) return;
      const interest = link.dataset.interest || '';
      const option = Array.from(interestSelect.options).find((item) => item.text.toLowerCase() === interest.toLowerCase() || item.value.toLowerCase() === interest.toLowerCase());
      if (option) interestSelect.value = option.value;
      else if (interest.toLowerCase().includes('b2b')) interestSelect.value = 'B2B / B2C / D2C platforms';
      else if (interest.toLowerCase().includes('digital business')) interestSelect.value = 'Digital Business & Commerce';
      else if (interest.toLowerCase().includes('ai')) interestSelect.value = 'AI & Research';
    });
  });

  // Project enquiries: append to Google Sheets and email the team via the deployed Apps Script web app.
  const contactForm = $('#contactForm');
  const formStatus = $('#formStatus');
  if (contactForm) {
    const startedField = contactForm.querySelector('[name="submission_started_at"]');
    if (startedField) startedField.value = String(Date.now());

    contactForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;

      const endpoint = (window.FQ_GOOGLE_APPS_SCRIPT_URL || '').trim();
      const submitButton = contactForm.querySelector('button[type="submit"]');
      const showStatus = (message, state) => {
        if (!formStatus) return;
        formStatus.textContent = message;
        formStatus.classList.add('visible');
        formStatus.dataset.state = state || 'info';
      };

      if (!/^https:\/\/script\.google\.com\/macros\/s\/[^/]+\/exec(?:\?.*)?$/.test(endpoint)) {
        showStatus('Enquiry delivery is not configured yet. Please email info@frontiersquantum.com or call +91 7032166374 while the form is being connected.', 'error');
        return;
      }

      const formData = new FormData(contactForm);
      const payload = Object.fromEntries(formData.entries());
      payload.form_name = contactForm.getAttribute('name') || 'website-enquiry';
      payload.page_url = window.location.href;
      payload.submitted_at_client = new Date().toISOString();
      payload.user_agent = navigator.userAgent;

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.setAttribute('aria-busy', 'true');
      }
      showStatus('Sending your enquiry securely…', 'info');

      try {
        // text/plain + no-cors avoids a browser preflight against Google's Apps Script web-app endpoint.
        // The response is opaque, so this confirms dispatch from the browser, not downstream email delivery.
        await fetch(endpoint, {
          method: 'POST',
          mode: 'no-cors',
          redirect: 'follow',
          headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
          body: JSON.stringify(payload)
        });
        contactForm.reset();
        if (startedField) startedField.value = String(Date.now());
        showStatus('Your enquiry has been sent for processing. Our team will contact you using the details provided. For urgent follow-up, email info@frontiersquantum.com.', 'success');
      } catch (error) {
        showStatus('We could not send your enquiry from this browser. Please email info@frontiersquantum.com or try again later.', 'error');
      } finally {
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.removeAttribute('aria-busy');
        }
      }
    });
  }

  // Scroll reveals. Content is left visible on reduced-motion or older-browser configurations.
  const revealSelectors = [
    '.intro-content', '.section-heading', '.service-card', '.industry-card', '.industry-note',
    '.models-intro', '.model-panel', '.approach-step', '.contact-form', '.innovation-preview-copy',
    '.innovation-mini-card', '.spotlight-card', '.insight-card', '.detail-service-card', '.solution-card',
    '.industry-detail-card', '.innovation-area-card', '.lab-timeline article', '.mission-vision-grid article',
    '.approach-value-grid article', '.partner-lanes > div', '.contact-promise-list > div', '.contact-intent-grid a'
  ];
  const revealTargets = Array.from(new Set(revealSelectors.flatMap((selector) => $$(selector))));
  if (!prefersReducedMotion && 'IntersectionObserver' in window && revealTargets.length) {
    revealTargets.forEach((element, index) => {
      element.classList.add('reveal-on-scroll');
      element.style.setProperty('--reveal-delay', `${(index % 4) * 55}ms`);
    });
    document.body.classList.add('motion-enabled');
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-revealed');
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.01, rootMargin: '180px 0px 180px 0px' });
    revealTargets.forEach((element) => revealObserver.observe(element));
    // Fallback for fast scrolls: any element entering the near viewport is revealed even if its
    // intersection was skipped between frames (e.g. a high-speed touch gesture).
    const revealNearViewport = () => {
      revealTargets.forEach((element) => {
        if (element.classList.contains('is-revealed')) return;
        const rect = element.getBoundingClientRect();
        if (rect.top < window.innerHeight + 260 && rect.bottom > -260) {
          element.classList.add('is-revealed');
          revealObserver.unobserve(element);
        }
      });
    };
    window.addEventListener('scroll', revealNearViewport, { passive: true });
    window.addEventListener('resize', revealNearViewport, { passive: true });
    window.setTimeout(revealNearViewport, 80);
  }

  // Pointer-follow lighting and a gentle cursor parallax on the cinematic hero.
  if (finePointer && !prefersReducedMotion) {
    $$('.service-card, .industry-card, .model-panel, .spotlight-card, .solution-card, .insight-card, .innovation-area-card, .industry-detail-card').forEach((card) => {
      card.addEventListener('pointermove', (event) => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty('--pointer-x', `${event.clientX - rect.left}px`);
        card.style.setProperty('--pointer-y', `${event.clientY - rect.top}px`);
      });
      card.addEventListener('pointerleave', () => {
        card.style.removeProperty('--pointer-x');
        card.style.removeProperty('--pointer-y');
      });
    });
    const hero = $('#home-hero') || $('.inner-hero');
    if (hero) {
      hero.addEventListener('pointermove', (event) => {
        const rect = hero.getBoundingClientRect();
        const dx = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
        const dy = ((event.clientY - rect.top) / rect.height - 0.5) * 2;
        hero.style.setProperty('--scene-shift-x', `${dx * 7}px`);
        hero.style.setProperty('--scene-shift-y', `${dy * 5}px`);
      });
      hero.addEventListener('pointerleave', () => {
        hero.style.removeProperty('--scene-shift-x');
        hero.style.removeProperty('--scene-shift-y');
      });
    }
  }

  // Touch/click feedback. No ripple is created for reduced-motion visitors.
  if (!prefersReducedMotion) {
    $$('.button, .nav-cta, .service-card, .industry-card, .model-tab, .underlined-link, .text-link, .spotlight-card, .solution-card, .contact-intent-grid a').forEach((target) => {
      target.addEventListener('pointerdown', (event) => {
        if (event.button > 0 || event.pointerType === 'mouse' && event.button !== 0) return;
        const rect = target.getBoundingClientRect();
        const ripple = document.createElement('span');
        ripple.className = 'tap-ripple';
        ripple.setAttribute('aria-hidden', 'true');
        ripple.style.left = `${event.clientX - rect.left}px`;
        ripple.style.top = `${event.clientY - rect.top}px`;
        if (getComputedStyle(target).position === 'static') target.style.position = 'relative';
        target.appendChild(ripple);
        ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
      }, { passive: true });
    });
  }

  // Lightweight particle network, with lower density on mobile and no animation for reduced-motion users.
  const canvas = $('#quantumCanvas');
  if (canvas && !prefersReducedMotion) {
    const ctx = canvas.getContext('2d', { alpha: true });
    if (ctx) {
      const hero = canvas.closest('.hero');
      const particles = [];
      const pointer = { x: -1000, y: -1000, active: false };
      let width = 0;
      let height = 0;
      let frame = 0;
      let raf = 0;
      let lastPaint = 0;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
      const makeParticle = () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.19,
        vy: (Math.random() - 0.5) * 0.19,
        r: Math.random() * 1.5 + 0.45,
        hue: Math.random() > 0.78 ? '85,217,232' : '255,135,61',
        phase: Math.random() * Math.PI * 2
      });
      const resize = () => {
        const rect = canvas.getBoundingClientRect();
        width = Math.max(1, rect.width);
        height = Math.max(1, rect.height);
        canvas.width = Math.round(width * dpr);
        canvas.height = Math.round(height * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const desired = Math.min(width < 650 ? 38 : 78, Math.max(22, Math.floor(width * height / 13000)));
        while (particles.length < desired) particles.push(makeParticle());
        while (particles.length > desired) particles.pop();
      };
      const draw = (timestamp) => {
        raf = window.requestAnimationFrame(draw);
        if (timestamp - lastPaint < 32) return;
        lastPaint = timestamp;
        frame += 0.016;
        ctx.clearRect(0, 0, width, height);
        for (let i = 0; i < particles.length; i++) {
          const p = particles[i];
          if (pointer.active) {
            const dx = p.x - pointer.x;
            const dy = p.y - pointer.y;
            const dist = Math.hypot(dx, dy);
            if (dist > 0 && dist < 115) {
              const force = (115 - dist) / 115 * 0.018;
              p.vx += dx / dist * force;
              p.vy += dy / dist * force;
            }
          }
          p.x += p.vx;
          p.y += p.vy;
          p.vx *= 0.997;
          p.vy *= 0.997;
          p.x += Math.sin(frame + p.phase) * 0.05;
          p.y += Math.cos(frame * 0.7 + p.phase) * 0.045;
          if (p.x < -10) p.x = width + 10;
          if (p.x > width + 10) p.x = -10;
          if (p.y < -10) p.y = height + 10;
          if (p.y > height + 10) p.y = -10;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${p.hue},${0.4 + (Math.sin(frame + p.phase) + 1) * 0.2})`;
          ctx.fill();
          for (let j = i + 1; j < particles.length; j++) {
            const q = particles[j];
            const distance = Math.hypot(p.x - q.x, p.y - q.y);
            if (distance < 92) {
              const alpha = (1 - distance / 92) * 0.14;
              ctx.beginPath();
              ctx.moveTo(p.x, p.y);
              ctx.lineTo(q.x, q.y);
              ctx.strokeStyle = `rgba(${p.hue},${alpha})`;
              ctx.lineWidth = 0.6;
              ctx.stroke();
            }
          }
        }
        if (pointer.active) {
          const glow = ctx.createRadialGradient(pointer.x, pointer.y, 0, pointer.x, pointer.y, 120);
          glow.addColorStop(0, 'rgba(255,135,61,0.06)');
          glow.addColorStop(1, 'rgba(255,135,61,0)');
          ctx.fillStyle = glow;
          ctx.fillRect(pointer.x - 120, pointer.y - 120, 240, 240);
        }
      };
      if (hero) {
        hero.addEventListener('pointermove', (event) => {
          const rect = canvas.getBoundingClientRect();
          pointer.x = event.clientX - rect.left;
          pointer.y = event.clientY - rect.top;
          pointer.active = true;
        }, { passive: true });
        hero.addEventListener('pointerleave', () => { pointer.active = false; }, { passive: true });
      }
      resize();
      window.addEventListener('resize', resize, { passive: true });
      raf = window.requestAnimationFrame(draw);
      window.addEventListener('pagehide', () => window.cancelAnimationFrame(raf), { once: true });
    }
  }

  // Load the optional 3D companion only when a visitor scrolls near its section.
  // The CSS illustration remains available if WebGL or the remote module cannot load.
  const robotStage = $('#fqRobotStage');
  if (robotStage) {
    const loadRobot = () => import('./quantum-robot.js').catch((error) => {
      console.warn('Optional 3D companion did not load; keeping the static fallback.', error);
    });
    if ('IntersectionObserver' in window) {
      const robotObserver = new IntersectionObserver((entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          robotObserver.disconnect();
          loadRobot();
        }
      }, { rootMargin: '320px 0px', threshold: 0.01 });
      robotObserver.observe(robotStage);
    } else {
      loadRobot();
    }
  }

  const year = $('#year');
  if (year) year.textContent = new Date().getFullYear();
})();
