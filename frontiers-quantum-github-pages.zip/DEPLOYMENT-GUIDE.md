# Frontiers Quantum — premium website deployment guide

**Domain:** `frontiersquantum.com`  
**Brand:** Frontiers Quantum — *Beyond Possibilities*

## Included website

The `frontiers-quantum-website` folder is a complete static website. No Node.js build, package installation, framework runtime or build command is required.

- Homepage, Services, Solutions, Industries, Innovation, Company, Insights and Contact pages.
- Three editorial insights, a thank-you page, responsive shared navigation and Google Apps Script enquiry forms.
- Shared design system: `styles.css` and `script.js`.
- Advanced motion layer: `premium-motion.css` and `premium-motion.js`.
- Optimized WebP/SVG artwork plus a 1200×628 social-preview image, favicon, page-specific SEO metadata and structured data, `404.html`, `robots.txt`, `sitemap.xml`, and `netlify.toml`.
- `SEO-IMPLEMENTATION-REPORT.md` documents the SEO changes and the checks that still require the live domain.

## Preview locally on Windows

1. Extract the ZIP archive.
2. Open the `frontiers-quantum-website` folder.
3. Double-click `start-preview.bat`, or open PowerShell/Command Prompt in that folder and run:

   ```powershell
   py -m http.server 8000
   ```

4. Visit `http://localhost:8000`. Stop the server with `Ctrl+C`.

A local HTTP server is preferable to opening HTML files directly because it mirrors the deployed URL structure.

## Deploy on Netlify

1. Create or select a Git repository and upload the **contents** of `frontiers-quantum-website` (not its parent directory).
2. In Netlify, import the repository. Set the publish directory to `.` and leave the build command empty.
3. Follow `GOOGLE-SHEETS-EMAIL-SETUP.md` to create the enquiry spreadsheet and deploy the Apps Script Web App.
4. Paste the deployed `/exec` URL into `form-config.js`, commit the change and redeploy. Test both enquiry forms; verify a new Google Sheet row and an email with a CSV attachment arrive at `info@frontiersquantum.com`. The local preview validates form fields but cannot deliver messages.
5. In **Domain management**, add `frontiersquantum.com` and optionally `www.frontiersquantum.com`. At your registrar, apply the exact DNS values Netlify shows for your site. Do not copy generic DNS values from unrelated examples.
6. Select the primary domain, enable HTTPS, and verify redirects for the root domain and `www`.
7. Confirm `/robots.txt` and `/sitemap.xml` load on the deployed domain and submit the sitemap to Google Search Console.
8. Inspect the homepage, Services, Solutions and each article URL in Search Console; request indexing where appropriate. A successful request does not guarantee indexing.
9. Run PageSpeed Insights against the deployed homepage and key service pages. Fix issues indicated by field data and diagnostics rather than targeting a score alone.

Both enquiry forms use the Google Apps Script endpoint. The forms are not live until the `/exec` URL is set in `form-config.js` and a real test confirms that Google Sheets logging and email notifications work. The browser-side no-CORS request cannot read the Apps Script response, so validate delivery in the spreadsheet and inbox.

## Before launch

- Verify that capability descriptions match the company's actual service offerings.
- Confirm the published company contact details and add a privacy notice describing form-data processing and retention.
- Complete the Google Apps Script setup and test real submissions, Google Sheet logging, CSV attachments and notification delivery.
- Test the domain and HTTPS, then run Lighthouse/PageSpeed and an automated WCAG checker on the deployed site.
- Review keyboard navigation, reduced motion, screen-reader output and touch behavior on real devices.

The site does not add fabricated client logos, testimonials, business metrics or case studies. Production DNS, form delivery, Core Web Vitals and a full accessibility audit are not verified by the local test report.

## Revision 02 motion and brand notes

The updated package keeps the cinematic homepage hero and adds CSS/SVG service illustrations, animated sector accents, and model-specific B2B/B2C/D2C diagrams. The FRONTIERS wordmark is set to a light foreground and QUANTUM to orange on dark surfaces. The decorative animation layer respects `prefers-reduced-motion`. Review `TEST-REPORT.md` for checks completed and items that still require a deployed domain.
