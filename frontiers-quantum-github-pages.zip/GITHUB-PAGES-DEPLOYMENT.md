# Frontiers Quantum — GitHub Pages deployment

This website is plain HTML, CSS and JavaScript. It has no Node.js dependencies and requires no build command.

## 1. Upload the files at the repository root

1. Download and extract `frontiers-quantum-github-pages.zip` on your computer.
2. Open the extracted folder. You should immediately see `index.html`, `styles.css`, `assets/`, `contact.html`, and `.github/`.
3. Upload/commit the **contents of this folder** to the root of your GitHub repository on the `main` branch. Do not upload the ZIP itself and do not put the files inside another folder.
4. The repository root must contain `index.html` directly.

The included `.github/workflows/static.yml` replaces the usual GitHub Pages Static HTML workflow template. If GitHub already created `.github/workflows/static.yml`, overwrite it with this version. Keep only one workflow that deploys this site to Pages; remove any duplicate Pages deployment workflow from `.github/workflows/`.

## 2. Enable GitHub Pages

1. Open **Repository → Settings → Pages**.
2. Under **Build and deployment → Source**, select **GitHub Actions**.
3. Commit the files to `main`. The included workflow runs automatically after the push. You can also run it manually from **Actions → Deploy static website to GitHub Pages → Run workflow**.
4. Open **Actions** and confirm the deployment run finishes with green check marks.
5. Return to **Settings → Pages** and open the published site URL.

If your default branch is not named `main`, edit `.github/workflows/static.yml` and replace `main` under `on.push.branches` with your branch name.

## 3. What the package fixes

- Moves `index.html` and all website files to the ZIP's top level, so Pages can find the entry file.
- Makes local page, image and CSS links relative so the site works at both a project URL such as `https://ACCOUNT.github.io/REPOSITORY/` and a custom-domain root.
- Includes `.nojekyll` and a GitHub Pages Actions deployment workflow.
- Retains the site's existing pages, assets, SEO files and custom 404 page.

## 4. Important launch checks

- **Contact form:** `form-config.js` currently has an empty Google Apps Script URL. The website will render, but enquiry submission will remain unavailable until you deploy the included `google-apps-script/Code.gs` as a Google Apps Script Web App and paste its `/exec` URL into `form-config.js`. Follow `GOOGLE-SHEETS-EMAIL-SETUP.md`, then commit the updated `form-config.js`.
- **Custom domain:** the SEO canonical URLs, Open Graph URLs, `robots.txt` and `sitemap.xml` are currently set for `https://frontiersquantum.com/`. After deployment, configure `frontiersquantum.com` under **Settings → Pages → Custom domain** and configure the DNS records shown by GitHub at your DNS provider. Do not add a custom domain unless you control it. The default `github.io` URL can be used to test the site first.
- **Security headers:** `netlify.toml` is retained for Netlify hosting, but GitHub Pages does not apply Netlify's custom response-header rules. Do not assume those headers are active on GitHub Pages.
- **Public repository:** GitHub Pages content is publicly accessible. Do not put passwords, API secrets, customer data or private files in the repository.

## 5. Expected repository structure

```text
repository-root/
├── index.html
├── 404.html
├── contact.html
├── services.html
├── solutions.html
├── industries.html
├── innovation.html
├── company.html
├── insights.html
├── insights/
├── assets/
├── styles.css
├── script.js
├── form-config.js
├── .nojekyll
└── .github/
    └── workflows/
        └── static.yml
```
