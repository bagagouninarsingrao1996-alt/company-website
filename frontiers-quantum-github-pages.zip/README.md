> **GitHub Pages:** This ZIP is also prepared for GitHub Pages. Extract it and upload the folder contents to the repository root (not the ZIP and not an enclosing folder), then follow [GITHUB-PAGES-DEPLOYMENT.md](GITHUB-PAGES-DEPLOYMENT.md). The site does not require a build command.

# Frontiers Quantum — Corporate Website

**Brand:** Frontiers Quantum · **Tagline:** Beyond Possibilities · **Domain:** `frontiersquantum.com`

A responsive, multi-page static corporate website with the retained “Make the next move matter.” hero, a glowing infinity identity, original orange/cyan motion graphics, scroll-reactive backgrounds, touch feedback, pointer-responsive lighting, accessible navigation, and reduced-motion support. It uses the supplied logo and artwork from the existing source ZIP and extends them into a reusable site system.

## What's included

- `index.html` — cinematic homepage, capabilities, industries, B2B/B2C/D2C selector, approach, innovation preview, capability spotlights, insights and project enquiry.
- `services.html` — cybersecurity, AI & R&D, digital engineering, and digital transformation.
- `solutions.html` — B2B/B2C/D2C platforms, e-commerce, CRM, HRMS, payroll, billing, payment gateways, service management and integrations.
- `industries.html` — banking and financial services, insurance, healthcare, industrial and hospitality.
- `innovation.html` — applied AI, secure innovation, connected data, prototypes and emerging technology exploration.
- `company.html` — overview, mission, vision, approach, partnerships and careers.
- `insights.html` + `insights/` — three original editorial notes and an explicit policy against invented client stories or performance claims.
- `contact.html` — project, partnership, career and research enquiries.
- `thank-you.html` — retained branded acknowledgement page, deliberately marked `noindex`.
- `404.html` — branded not-found page for static hosting.
- `SEO-IMPLEMENTATION-REPORT.md` — implementation summary, validation boundaries and post-deployment checks.
- `SEO-STRATEGY-AND-AUDIT.md` — source audit, page-to-keyword mapping, local SEO, backlink strategy, 90-day content calendar, Core Web Vitals and measurement setup.
- `styles.css`, `script.js` — shared design system, responsive layouts and core interactions.
- `premium-motion.css`, `premium-motion.js` — scroll-reactive infinity engravings, animated logo traces, particle runners, moving section energy fields, scroll progress, editorial reveals, restrained pointer tilt and magnetic CTAs. Revision 02 adds motion-led service and sector illustrations, distinct SVG diagrams for B2B/B2C/D2C, and a high-contrast wordmark (light FRONTIERS + orange QUANTUM) on dark surfaces.
- `assets/` — supplied logo, optimized WebP hero art, SVG network graphic and a 1200×628 JPEG social-preview image.
- `robots.txt`, `sitemap.xml`, `netlify.toml` — deployment and SEO support.

## Run locally on Windows

1. Extract the ZIP.
2. Open the extracted `frontiers-quantum-website` folder.
3. Double-click `start-preview.bat`, or open PowerShell / Command Prompt in that folder and run:

   ```bash
   py -m http.server 8000
   ```

4. Open `http://localhost:8000` in your browser. Stop the preview with `Ctrl+C`.

You can also open `index.html` directly for a quick visual check, but a local HTTP server is closer to the production environment.

## Deploy to `frontiersquantum.com` (static hosting)

The site has no build step or JavaScript framework dependency. The premium motion layer is progressive enhancement: navigation, copy, pages and form markup remain usable if its JavaScript is unavailable.

1. Create a Git repository and upload the contents of this folder (not the parent folder).
2. In Netlify, import that repository as a new site. Use the repository root as the publish directory and leave the build command empty. The included `netlify.toml` also sets the publish directory to `.`.
3. Configure the Google Sheets and email integration by following `GOOGLE-SHEETS-EMAIL-SETUP.md`. Run `setup()` in Apps Script, deploy it as a Web App, and paste the resulting `/exec` URL into `form-config.js`.
4. Submit a test enquiry from both the homepage and Contact page. Confirm each submission creates a Google Sheet row and an email to `info@frontiersquantum.com` with a CSV attachment. Do not consider enquiry delivery production-ready until this test passes.
5. In Netlify's domain settings, add `frontiersquantum.com` and (optionally) `www.frontiersquantum.com`. At your domain registrar, apply the exact DNS records / nameservers Netlify presents for your site. DNS values vary by account and current hosting configuration, so use the values Netlify displays rather than copying generic IPs.
6. Set the preferred primary domain, enable HTTPS in the Netlify domain settings and verify both the root domain and `www` redirect as intended.
7. After launch, verify `https://frontiersquantum.com/robots.txt` and `https://frontiersquantum.com/sitemap.xml` and resubmit the sitemap to your search-console account.

**Contact form note:** both enquiry forms use the Google Apps Script Web App configured in `form-config.js`. Submissions will not be delivered until the endpoint is deployed and configured. The browser uses a no-CORS request, so confirm delivery by checking the Google Sheet and notification inbox. Never collect credentials or sensitive data in this form.

## Alternative hosting

The static HTML/CSS/JS can be hosted on Netlify, GitHub Pages or another static host. The same Google Apps Script endpoint works across these hosts; configure `form-config.js` before collecting enquiries.

## Motion, performance and accessibility

- Particle canvas uses a bounded particle count and connection radius, with lower density on mobile.
- The infinity symbol is animated in the header/footer, traced across cinematic hero art, and echoed as an SVG signature in selected sections. A scroll-linked energy field shifts behind each section; a top-edge progress line reflects overall page position. Service cards use distinct cybersecurity, AI, commerce and transformation visuals; industry cards carry subtle sector-specific motion; the B2B/B2C/D2C tab panel swaps its diagram with the selected model.
- Scroll-based editorial reveals have an explicit near-viewport fallback for fast scrolling; decorative grid/glow shifts stay behind content. Pointer tilt/magnetic response is enabled only for fine pointers.
- Reduced-motion preferences disable the particle animation, parallax, ripples and reveal transitions.
- Interactive tabs support arrow keys, Home and End; the mobile navigation has accessible state labels and Escape-key close behavior.
- Images use WebP / SVG. The mark has been resized for display scale and the hero asset is preloaded for the first view.
- Public pages use page-specific titles and descriptions, canonical URLs, Open Graph/Twitter preview metadata and page-appropriate JSON-LD (`Organization`, `WebSite`, `WebPage`, `ContactPage`, `Service` or `BlogPosting`). The thank-you and 404 pages are marked `noindex`; the sitemap contains only the 11 intended public pages.
- There are no fabricated client logos, testimonials, metrics or case-study claims.

## Revision 02 notes

- The “Make the next move matter.” hero direction is retained. New service, model and industry graphics are built with CSS/SVG rather than external animation libraries.
- The shared brand wordmark explicitly uses a light color for FRONTIERS and orange for QUANTUM, fixing the dark-background readability issue in the company/footer area.
- `TEST-REPORT.md` records the exact checks run and clearly separates source/browser-harness checks from deployment-only checks.

## Pre-launch checklist

- [ ] Replace or confirm any capability copy that does not exactly reflect the company's offer.
- [ ] Deploy Google Apps Script, configure `form-config.js`, and test real Google Sheet + email delivery.
- [x] Add Hyderabad, Telangana contact location, both phone numbers, business email and LinkedIn profile.
- [ ] Publish a privacy notice that explains Google Sheets processing, email notifications, retention and contact rights.
- [ ] Verify DNS, HTTPS, redirects and sitemap after connecting the domain.
- [ ] Verify the domain in Google Search Console, submit `sitemap.xml`, and inspect the homepage and key service/article URLs.
- [ ] Run PageSpeed Insights on the homepage and key landing pages, then address measured bottlenecks.
- [ ] Review the site on real iOS and Android devices and a screen reader before production release.

## Homepage signature visuals (October 2026)

The homepage now combines two visual treatments while keeping the Frontiers Quantum navy, orange and cyan identity:

- The main hero uses a muted, looping CloudFront MP4 background with the existing poster artwork as its fallback. The video source is defined in `index.html` and can be replaced there.
- The Innovation Lab includes a procedural 3D intelligence companion in `quantum-robot.js`. It uses Three.js 0.160.0 and the `RoundedBoxGeometry` / `RoomEnvironment` addons through the import map in `index.html`. No external 3D model or image file is needed.
- `signature-visuals.css` contains the scoped layout and responsive treatment; `signature-visuals.js` handles reduced-motion and page-visibility playback for the hero video.
- If WebGL is unavailable or the Three.js CDN cannot load, a CSS fallback illustration remains visible in the Innovation Lab stage.

This is a static-site addition: no npm install, bundler or build step is required. Deploy the full website folder so the new CSS and JavaScript files are published alongside `index.html`.
