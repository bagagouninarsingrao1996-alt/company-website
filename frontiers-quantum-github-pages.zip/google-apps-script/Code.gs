/**
 * Frontiers Quantum website enquiry integration.
 *
 * What it does:
 *  - Appends each valid website enquiry to a private Google Spreadsheet.
 *  - Emails info@frontiersquantum.com with the enquiry details.
 *  - Attaches a one-enquiry CSV file and includes the Google Sheet link.
 *
 * Initial setup: run setup() once from the Apps Script editor and authorize it.
 * Deploy as a Web App (execute as you; access: anyone), then copy the /exec URL
 * into ../form-config.js in the website project.
 */

const FQ_CONFIG = {
  notificationEmail: 'info@frontiersquantum.com',
  spreadsheetName: 'Frontiers Quantum - Website Enquiries',
  sheetName: 'Enquiries',
  rateLimitSeconds: 30,
  maxNameLength: 120,
  maxEmailLength: 254,
  maxCompanyLength: 160,
  maxTypeLength: 80,
  maxInterestLength: 120,
  maxMessageLength: 8000,
  maxPageUrlLength: 1000
};

const FQ_HEADERS = [
  'Received At',
  'Form',
  'Full Name',
  'Email',
  'Company',
  'Enquiry Type',
  'Area of Interest',
  'Enquiry Details',
  'Consent',
  'Page URL',
  'Email Notification'
];

/** Run manually once. Creates the enquiry spreadsheet if it does not exist. */
function setup() {
  const properties = PropertiesService.getScriptProperties();
  let spreadsheetId = properties.getProperty('FQ_SPREADSHEET_ID');
  let spreadsheet;

  if (spreadsheetId) {
    try {
      spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    } catch (error) {
      spreadsheetId = '';
    }
  }

  if (!spreadsheetId) {
    spreadsheet = SpreadsheetApp.create(FQ_CONFIG.spreadsheetName);
    spreadsheetId = spreadsheet.getId();
    properties.setProperty('FQ_SPREADSHEET_ID', spreadsheetId);
  }

  properties.setProperty('FQ_NOTIFICATION_EMAIL', FQ_CONFIG.notificationEmail);
  let sheet = spreadsheet.getSheetByName(FQ_CONFIG.sheetName);
  if (!sheet) {
    const existingSheets = spreadsheet.getSheets();
    if (existingSheets.length === 1 && existingSheets[0].getLastRow() === 0) {
      sheet = existingSheets[0];
      sheet.setName(FQ_CONFIG.sheetName);
    } else {
      sheet = spreadsheet.insertSheet(FQ_CONFIG.sheetName);
    }
  }

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, FQ_HEADERS.length).setValues([FQ_HEADERS]);
    sheet.getRange(1, 1, 1, FQ_HEADERS.length)
      .setFontWeight('bold')
      .setBackground('#101a30')
      .setFontColor('#ffffff');
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, FQ_HEADERS.length);
    sheet.setColumnWidth(8, 420);
    sheet.setColumnWidth(10, 280);
    sheet.getRange('A:A').setNumberFormat('yyyy-mm-dd hh:mm:ss');
    sheet.getRange('D:D').setNumberFormat('@');
  }

  Logger.log('Enquiry spreadsheet created/ready: ' + spreadsheet.getUrl());
  Logger.log('Spreadsheet ID saved in Script Properties. Notification email: ' + FQ_CONFIG.notificationEmail);
  return spreadsheet.getUrl();
}

/** Simple endpoint health check. */
function doGet() {
  return jsonOutput_({ ok: true, service: 'Frontiers Quantum enquiry endpoint', status: 'ready' });
}

/** Receives JSON text from the website's no-cors POST request. */
function doPost(event) {
  try {
    const raw = event && event.postData && event.postData.contents;
    if (!raw) return jsonOutput_({ ok: false, error: 'Empty request body' });

    let payload;
    try {
      payload = JSON.parse(raw);
    } catch (parseError) {
      return jsonOutput_({ ok: false, error: 'Invalid request format' });
    }

    // Honeypot: silently ignore likely automated spam.
    if (clean_(payload['bot-field'], 300)) {
      return jsonOutput_({ ok: true, accepted: true });
    }

    const enquiry = validateAndNormalize_(payload);
    if (!enquiry.ok) return jsonOutput_({ ok: false, error: enquiry.error });

    const lock = LockService.getScriptLock();
    lock.waitLock(15000);
    try {
      const cache = CacheService.getScriptCache();
      const emailKey = 'fq_last_' + sha256_(enquiry.data.email.toLowerCase());
      if (cache.get(emailKey)) {
        return jsonOutput_({ ok: false, error: 'Please wait before sending another enquiry.' });
      }
      cache.put(emailKey, '1', FQ_CONFIG.rateLimitSeconds);

      const spreadsheetId = PropertiesService.getScriptProperties().getProperty('FQ_SPREADSHEET_ID');
      if (!spreadsheetId) throw new Error('Run setup() in Apps Script before accepting enquiries.');

      const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
      const sheet = spreadsheet.getSheetByName(FQ_CONFIG.sheetName);
      if (!sheet) throw new Error('Enquiries sheet not found. Run setup() again.');

      const receivedAt = new Date();
      const row = [
        receivedAt,
        sheetSafe_(enquiry.data.formName),
        sheetSafe_(enquiry.data.name),
        sheetSafe_(enquiry.data.email),
        sheetSafe_(enquiry.data.company),
        sheetSafe_(enquiry.data.enquiryType),
        sheetSafe_(enquiry.data.interest),
        sheetSafe_(enquiry.data.message),
        'Yes',
        sheetSafe_(enquiry.data.pageUrl),
        'Pending'
      ];
      const rowNumber = sheet.getLastRow() + 1;
      sheet.getRange(rowNumber, 1, 1, row.length).setValues([row]);
      sheet.getRange(rowNumber, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
      SpreadsheetApp.flush();

      let mailStatus = 'Sent';
      try {
        sendEnquiryNotification_(enquiry.data, receivedAt, spreadsheet.getUrl());
      } catch (mailError) {
        mailStatus = 'Failed: ' + String(mailError.message || mailError).slice(0, 180);
        sheet.getRange(rowNumber, 11).setValue(mailStatus);
        throw new Error('Enquiry was recorded in the Google Sheet, but email notification failed. ' + mailStatus);
      }
      sheet.getRange(rowNumber, 11).setValue(mailStatus);
      return jsonOutput_({ ok: true, accepted: true });
    } finally {
      lock.releaseLock();
    }
  } catch (error) {
    console.error(error && error.stack ? error.stack : error);
    return jsonOutput_({ ok: false, error: String(error.message || error) });
  }
}

function validateAndNormalize_(payload) {
  const data = {
    formName: clean_(payload.form_name || payload.form_source || 'Website enquiry', 80),
    name: clean_(payload.name, FQ_CONFIG.maxNameLength),
    email: clean_(payload.email, FQ_CONFIG.maxEmailLength).toLowerCase(),
    company: clean_(payload.company, FQ_CONFIG.maxCompanyLength),
    enquiryType: clean_(payload.enquiry_type || payload.form_source || 'General', FQ_CONFIG.maxTypeLength),
    interest: clean_(payload.interest, FQ_CONFIG.maxInterestLength),
    message: clean_(payload.message, FQ_CONFIG.maxMessageLength),
    consent: clean_(payload.contact_permission, 10),
    pageUrl: clean_(payload.page_url, FQ_CONFIG.maxPageUrlLength)
  };

  if (data.name.length < 2) return { ok: false, error: 'Please provide your name.' };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) return { ok: false, error: 'Please provide a valid email address.' };
  if (data.message.length < 10) return { ok: false, error: 'Please provide more detail about your enquiry.' };
  if (data.consent.toLowerCase() !== 'yes') return { ok: false, error: 'Consent is required to process this enquiry.' };
  return { ok: true, data: data };
}

function sendEnquiryNotification_(data, receivedAt, spreadsheetUrl) {
  const recipient = PropertiesService.getScriptProperties().getProperty('FQ_NOTIFICATION_EMAIL') || FQ_CONFIG.notificationEmail;
  const safeSubjectType = (data.enquiryType || 'Website').replace(/[\r\n]/g, ' ').slice(0, 60);
  const safeSubjectName = data.name.replace(/[\r\n]/g, ' ').slice(0, 60);
  const subject = '[Frontiers Quantum] New ' + safeSubjectType + ' enquiry — ' + safeSubjectName;

  const fields = [
    ['Received at', receivedAt.toISOString()],
    ['Form', data.formName],
    ['Full name', data.name],
    ['Email', data.email],
    ['Company', data.company || 'Not provided'],
    ['Enquiry type', data.enquiryType || 'Not provided'],
    ['Area of interest', data.interest || 'Not provided'],
    ['Enquiry details', data.message],
    ['Consent', 'Yes'],
    ['Page URL', data.pageUrl || 'Not provided']
  ];

  const textBody = fields.map(function (field) { return field[0] + ':\n' + field[1]; }).join('\n\n') +
    '\n\nAll enquiries are recorded in the Google Sheet:\n' + spreadsheetUrl;

  const htmlBody = '<div style="font-family:Arial,sans-serif;max-width:680px;color:#172033">' +
    '<h2 style="color:#172033">New website enquiry</h2>' +
    '<table cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%">' +
    fields.map(function (field) {
      return '<tr><th align="left" valign="top" style="background:#f1f4f8;border:1px solid #dfe5ed;width:180px">' + escapeHtml_(field[0]) +
        '</th><td style="border:1px solid #dfe5ed;white-space:pre-wrap">' + escapeHtml_(field[1]) + '</td></tr>';
    }).join('') +
    '</table><p><a href="' + escapeHtml_(spreadsheetUrl) + '">Open the enquiry Google Sheet</a></p>' +
    '<p style="color:#68758b;font-size:12px">Frontiers Quantum website enquiry notification.</p></div>';

  const csvRows = [
    ['Received At', 'Form', 'Full Name', 'Email', 'Company', 'Enquiry Type', 'Area of Interest', 'Enquiry Details', 'Consent', 'Page URL'],
    [receivedAt.toISOString(), data.formName, data.name, data.email, data.company, data.enquiryType, data.interest, data.message, 'Yes', data.pageUrl]
  ];
  const csv = '\uFEFF' + csvRows.map(function (row) {
    return row.map(csvCell_).join(',');
  }).join('\r\n');
  const attachment = Utilities.newBlob(csv, 'text/csv', 'Frontiers-Quantum-Enquiry-' + Utilities.formatDate(receivedAt, Session.getScriptTimeZone(), 'yyyyMMdd-HHmmss') + '.csv');

  MailApp.sendEmail({
    to: recipient,
    subject: subject,
    body: textBody,
    htmlBody: htmlBody,
    replyTo: data.email,
    name: 'Frontiers Quantum Website',
    attachments: [attachment]
  });
}

function clean_(value, maxLength) {
  return String(value == null ? '' : value).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, maxLength);
}

// Prefix values that could otherwise be interpreted as spreadsheet formulas.
function sheetSafe_(value) {
  const text = String(value == null ? '' : value);
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

function csvCell_(value) {
  let text = String(value == null ? '' : value);
  if (/^[=+\-@]/.test(text)) text = "'" + text;
  return '"' + text.replace(/"/g, '""') + '"';
}

function escapeHtml_(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (character) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character];
  });
}

function sha256_(value) {
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, value, Utilities.Charset.UTF_8);
  return digest.map(function (byte) { return ('0' + ((byte + 256) % 256).toString(16)).slice(-2); }).join('');
}

function jsonOutput_(object) {
  return ContentService.createTextOutput(JSON.stringify(object)).setMimeType(ContentService.MimeType.JSON);
}
