@echo off
setlocal
cd /d "%~dp0"
echo Frontiers Quantum local preview
 echo Open http://localhost:8000 in your browser.
 echo Stop the server with Ctrl+C.
py -m http.server 8000
