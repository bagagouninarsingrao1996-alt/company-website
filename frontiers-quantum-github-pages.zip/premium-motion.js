/* Frontiers Quantum — scroll-reactive infinity/motion layer.
   Progressive enhancement: core navigation and content work without this file. */
(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const root = document.documentElement;

  // Keep the extra motion layer opt-in and add a top-edge progress signal.
  const progress = document.createElement('div');
  progress.className = 'fq-scroll-progress';
  progress.setAttribute('aria-hidden', 'true');
  progress.innerHTML = '<span class="fq-scroll-progress__fill"></span>';
  document.body.prepend(progress);

  const svgInfinity = (className, prefix, motif = false) => {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 800 380');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    svg.setAttribute('class', className);
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    const defs = document.createElementNS(svg.namespaceURI, 'defs');
    const gradient = document.createElementNS(svg.namespaceURI, 'linearGradient');
    gradient.setAttribute('id', `${prefix}-gradient`);
    gradient.setAttribute('x1', '0%'); gradient.setAttribute('y1', '50%');
    gradient.setAttribute('x2', '100%'); gradient.setAttribute('y2', '50%');
    const stops = [
      ['0%', '#ff6c26'], ['32%', '#ffc06b'], ['51%', '#fff0ca'], ['70%', '#58d9e8'], ['100%', '#ff7d36']
    ];
    stops.forEach(([offset, color]) => {
      const stop = document.createElementNS(svg.namespaceURI, 'stop');
      stop.setAttribute('offset', offset); stop.setAttribute('stop-color', color);
      gradient.appendChild(stop);
    });
    defs.appendChild(gradient);
    svg.appendChild(defs);

    const pathData = 'M400 190 C355 84 248 45 164 110 C73 181 93 263 164 300 C245 344 355 297 400 190 C445 84 552 45 636 110 C727 181 707 263 636 300 C555 344 445 297 400 190';
    if (motif) {
      const orbit = document.createElementNS(svg.namespaceURI, 'ellipse');
      orbit.setAttribute('class', 'fq-motif-orbit');
      orbit.setAttribute('cx', '400'); orbit.setAttribute('cy', '190');
      orbit.setAttribute('rx', '365'); orbit.setAttribute('ry', '132');
      orbit.setAttribute('transform', 'rotate(-11 400 190)');
      svg.appendChild(orbit);
      const faint = document.createElementNS(svg.namespaceURI, 'path');
      faint.setAttribute('class', 'fq-motif-track'); faint.setAttribute('d', pathData);
      faint.setAttribute('stroke', `url(#${prefix}-gradient)`); faint.style.stroke = `url(#${prefix}-gradient)`;
      svg.appendChild(faint);
      const trace = document.createElementNS(svg.namespaceURI, 'path');
      trace.setAttribute('class', 'fq-motif-track'); trace.setAttribute('d', pathData);
      trace.setAttribute('stroke', `url(#${prefix}-gradient)`); trace.style.stroke = `url(#${prefix}-gradient)`;
      trace.setAttribute('stroke-width', '.65'); trace.setAttribute('opacity', '.36');
      svg.appendChild(trace);
    } else {
      const halo = document.createElementNS(svg.namespaceURI, 'path');
      halo.setAttribute('class', 'fq-hero-halo'); halo.setAttribute('d', pathData);
      svg.appendChild(halo);
      const mainPath = document.createElementNS(svg.namespaceURI, 'path');
      mainPath.setAttribute('class', 'fq-hero-path'); mainPath.setAttribute('d', pathData); mainPath.style.stroke = `url(#${prefix}-gradient)`;
      svg.appendChild(mainPath);
      const cool = document.createElementNS(svg.namespaceURI, 'path');
      cool.setAttribute('class', 'fq-hero-path fq-hero-path--cool'); cool.setAttribute('d', pathData);
      cool.setAttribute('transform', 'translate(0 -10) scale(1 1.05)');
      svg.appendChild(cool);
      // Light particles run along the same infinity path to make the mark visibly kinetic.
      const addRunner = (runnerClass, radius, duration, delay) => {
        const runner = document.createElementNS(svg.namespaceURI, 'circle');
        runner.setAttribute('class', runnerClass);
        runner.setAttribute('r', String(radius));
        const motion = document.createElementNS(svg.namespaceURI, 'animateMotion');
        motion.setAttribute('path', pathData);
        motion.setAttribute('dur', duration);
        motion.setAttribute('begin', delay);
        motion.setAttribute('repeatCount', 'indefinite');
        motion.setAttribute('rotate', 'auto');
        runner.appendChild(motion);
        svg.appendChild(runner);
      };
      addRunner('fq-hero-pulse', 3.1, '7.5s', '-1.6s');
      addRunner('fq-hero-pulse fq-hero-pulse--cool', 2.1, '10.5s', '-5.2s');
    }
    return svg;
  };

  // Animate the existing brand mark, preserving the supplied raster logo.
  $$('.brand img[src*="fq-infinity-mark"]').forEach((img, index) => {
    if (img.parentElement?.classList.contains('brand-mark-wrap')) return;
    const wrap = document.createElement('span');
    wrap.className = 'brand-mark-wrap';
    img.parentNode.insertBefore(wrap, img);
    wrap.appendChild(img);
    const trace = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    trace.setAttribute('viewBox', '0 0 160 75');
    trace.setAttribute('class', 'fq-logo-trace');
    trace.setAttribute('aria-hidden', 'true');
    trace.setAttribute('focusable', 'false');
    const defs = document.createElementNS(trace.namespaceURI, 'defs');
    const gradient = document.createElementNS(trace.namespaceURI, 'linearGradient');
    gradient.id = `fq-logo-gradient-${index}`;
    gradient.innerHTML = '<stop offset="0%" stop-color="#ff6426"/><stop offset="49%" stop-color="#fff0c1"/><stop offset="70%" stop-color="#ffb75b"/><stop offset="100%" stop-color="#ff6426"/>';
    defs.appendChild(gradient); trace.appendChild(defs);
    const path = document.createElementNS(trace.namespaceURI, 'path');
    path.setAttribute('d', 'M80 38 C63 9 36 8 20 37 C36 65 63 67 80 38 C97 9 124 8 140 37 C124 65 97 67 80 38');
    path.style.stroke = `url(#fq-logo-gradient-${index})`;
    trace.appendChild(path); wrap.appendChild(trace);
    // Stagger sibling logos so header/footer feel like one system, not a synced GIF.
    path.style.animationDelay = `${index * -1.2}s`;
  });

  // Add an SVG trace over the existing image art, never replacing the original logo or hero visual.
  const heroArts = [];
  const homeVisual = $('.hero-visual');
  const innerArt = $('.inner-hero-art');
  if (homeVisual) heroArts.push(homeVisual);
  if (innerArt) heroArts.push(innerArt);
  heroArts.forEach((element, index) => {
    element.appendChild(svgInfinity('fq-hero-infinity', `fq-hero-${index}`, false));
    element.classList.add('fq-infinity-stage');
  });

  // The light field and an infinity etching travel under each major page section.
  const scenes = $$('main section');
  scenes.forEach((scene, index) => {
    scene.classList.add('fq-motion-scene');
    scene.dataset.fqSceneIndex = String(index);
    const field = document.createElement('div');
    field.className = 'fq-ambient-field';
    field.setAttribute('aria-hidden', 'true');
    scene.prepend(field);
    // Keep one path-traced brand engraving every other section to avoid animation clutter.
    if (index === 0 && scene.classList.contains('inner-hero') || index % 2 === 1) {
      scene.appendChild(svgInfinity('fq-section-motif', `fq-motif-${index}`, true));
    }
    if (scene.classList.contains('section-dark')) scene.dataset.fqTone = 'dark';
    else scene.dataset.fqTone = 'light';
  });

  // Reveal larger content blocks from alternating directions. Existing scroll reveals remain intact.
  const editorialTargets = $$('main .section-heading, main .intro-content, main .models-intro, main .innovation-preview-copy, main .inner-hero-copy, main .contact-page-copy, main .company-story-copy, main .contact-form-page, main .approach-layout > div:first-child');
  const uniqueEditorialTargets = Array.from(new Set(editorialTargets));
  if (!reduceMotion && 'IntersectionObserver' in window) {
    uniqueEditorialTargets.forEach((element, index) => {
      if (element.classList.contains('fq-scroll-reveal')) return;
      element.classList.add('fq-scroll-reveal');
      element.dataset.fqMotion = ['left', 'right', 'scale'][index % 3];
      element.style.setProperty('--fq-reveal-delay', `${(index % 3) * 70}ms`);
    });
    const editorialObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: .08, rootMargin: '0px 0px -4% 0px' });
    uniqueEditorialTargets.forEach((element) => {
      if (element.classList.contains('fq-scroll-reveal')) editorialObserver.observe(element);
    });
  }

  // Mark the current page in navigation, without relying on server-side routing.
  const path = window.location.pathname.replace(/\/$/, '/index.html');
  $$('.primary-nav .nav-link').forEach((link) => {
    try {
      const linkPath = new URL(link.href, window.location.href).pathname.replace(/\/$/, '/index.html');
      if (linkPath === path) link.setAttribute('aria-current', 'page');
    } catch (_) { /* Ignore malformed or relative navigation URLs. */ }
  });

  // A small magnetic response on primary actions, plus restrained 3D light on image-rich cards.
  if (finePointer && !reduceMotion) {
    $$('.button-primary, .nav-cta').forEach((element) => {
      element.classList.add('fq-magnetic');
      element.addEventListener('pointermove', (event) => {
        const rect = element.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width - .5;
        const y = (event.clientY - rect.top) / rect.height - .5;
        element.style.setProperty('--fq-mag-x', `${(x * 7).toFixed(2)}px`);
        element.style.setProperty('--fq-mag-y', `${(y * 5).toFixed(2)}px`);
      }, { passive: true });
      element.addEventListener('pointerleave', () => {
        element.style.setProperty('--fq-mag-x', '0px');
        element.style.setProperty('--fq-mag-y', '0px');
      }, { passive: true });
    });

    $$('.service-card, .spotlight-card, .insight-card, .solution-card, .industry-detail-card').forEach((card) => {
      card.classList.add('fq-tilt-card');
      card.addEventListener('pointermove', (event) => {
        const rect = card.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width;
        const y = (event.clientY - rect.top) / rect.height;
        card.style.setProperty('--fq-card-x', `${x * 100}%`);
        card.style.setProperty('--fq-card-y', `${y * 100}%`);
        card.style.setProperty('--fq-tilt-x', `${((.5 - y) * 3.5).toFixed(2)}deg`);
        card.style.setProperty('--fq-tilt-y', `${((x - .5) * 4.4).toFixed(2)}deg`);
        card.classList.add('fq-tilting');
      }, { passive: true });
      card.addEventListener('pointerleave', () => {
        card.classList.remove('fq-tilting');
        card.style.setProperty('--fq-tilt-x', '0deg');
        card.style.setProperty('--fq-tilt-y', '0deg');
      }, { passive: true });
    });
  }

  // Model-specific infographic: B2B ecosystem, B2C customer orbit, D2C owned journey.
  // Inline SVG keeps the graphic crisp and avoids a heavy third-party animation dependency.
  const modelPanel = $('#modelPanel');
  if (modelPanel) {
    const modelVisual = document.createElement('div');
    modelVisual.className = 'fq-model-visual';
    modelVisual.setAttribute('aria-hidden', 'true');
    modelVisual.addEventListener('animationend', () => modelVisual.classList.remove('fq-model-visual--arriving'));
    const modelArt = {
      b2b: `<svg viewBox="0 0 520 320" role="presentation" focusable="false">
        <circle class="fq-model-ring" cx="328" cy="160" r="112"/><circle class="fq-model-ring" cx="328" cy="160" r="84" style="animation-direction:reverse;animation-duration:27s"/>
        <path class="fq-model-wire" d="M328 160 216 72 137 121 M328 160 446 78 470 132 M328 160 215 250 126 216 M328 160 440 246 476 210"/>
        <path class="fq-model-wire fq-model-wire--warm" d="M216 72 328 160 446 78 M215 250 328 160 440 246"/>
        <rect class="fq-model-core" x="278" y="132" width="100" height="56" rx="14"/><text class="fq-model-core-mark" x="328" y="156">PLATFORM</text><text class="fq-model-label" x="328" y="173">CONNECTED CORE</text>
        <circle class="fq-model-node fq-model-node--warm" cx="216" cy="72" r="7"/><circle class="fq-model-node" cx="137" cy="121" r="5"/><circle class="fq-model-node" cx="446" cy="78" r="7"/><circle class="fq-model-node fq-model-node--warm" cx="470" cy="132" r="5"/><circle class="fq-model-node" cx="215" cy="250" r="7"/><circle class="fq-model-node fq-model-node--warm" cx="126" cy="216" r="5"/><circle class="fq-model-node" cx="440" cy="246" r="7"/><circle class="fq-model-node" cx="476" cy="210" r="5"/>
      </svg>`,
      b2c: `<svg viewBox="0 0 520 320" role="presentation" focusable="false">
        <circle class="fq-model-ring" cx="330" cy="160" r="116"/><circle class="fq-model-ring" cx="330" cy="160" r="86" style="animation-duration:23s"/><circle class="fq-model-ring" cx="330" cy="160" r="56" style="animation-direction:reverse;animation-duration:17s"/>
        <path class="fq-model-wire" d="M330 160 330 46 M330 160 426 92 M330 160 424 225 M330 160 330 273 M330 160 230 225 M330 160 230 92"/><path class="fq-model-wire fq-model-wire--warm" d="M230 92 Q330 18 426 92 M230 225 Q330 301 424 225"/>
        <circle class="fq-model-core" cx="330" cy="160" r="36"/><text class="fq-model-core-mark" x="330" y="157">YOU</text><text class="fq-model-label" x="330" y="173">CUSTOMER</text>
        <circle class="fq-model-node fq-model-node--warm" cx="330" cy="46" r="7"/><circle class="fq-model-node" cx="426" cy="92" r="7"/><circle class="fq-model-node fq-model-node--warm" cx="424" cy="225" r="7"/><circle class="fq-model-node" cx="330" cy="273" r="7"/><circle class="fq-model-node fq-model-node--warm" cx="230" cy="225" r="7"/><circle class="fq-model-node" cx="230" cy="92" r="7"/>
      </svg>`,
      d2c: `<svg viewBox="0 0 520 320" role="presentation" focusable="false">
        <path class="fq-model-wire" d="M105 202 C160 202 160 112 230 112 S310 202 365 202 S427 116 474 116"/><path class="fq-model-wire fq-model-wire--warm" d="M105 202 C160 202 160 112 230 112 S310 202 365 202 S427 116 474 116" style="stroke-dasharray:3 13;animation-duration:6s"/>
        <circle class="fq-model-ring" cx="230" cy="112" r="48"/><circle class="fq-model-ring" cx="365" cy="202" r="43" style="animation-direction:reverse"/>
        <rect class="fq-model-core" x="64" y="178" width="82" height="48" rx="11"/><text class="fq-model-core-mark" x="105" y="198">BRAND</text><text class="fq-model-label" x="105" y="212">OWNED</text>
        <circle class="fq-model-core" cx="230" cy="112" r="29"/><text class="fq-model-core-mark" x="230" y="116">SHOP</text>
        <circle class="fq-model-core" cx="365" cy="202" r="29"/><text class="fq-model-core-mark" x="365" y="206">DATA</text>
        <circle class="fq-model-node fq-model-node--warm" cx="474" cy="116" r="7"/><text class="fq-model-label" x="474" y="99">CUSTOMER</text><circle class="fq-model-node" cx="105" cy="202" r="4"/>
      </svg>`
    };
    const updateModelVisual = (key) => {
      const model = Object.prototype.hasOwnProperty.call(modelArt, key) ? key : 'b2b';
      modelPanel.dataset.modelActive = model;
      modelVisual.innerHTML = modelArt[model];
      modelVisual.classList.remove('fq-model-visual--arriving');
      // Force a tiny visual reset so each model selection has a purposeful transition.
      void modelVisual.offsetWidth;
      modelVisual.classList.add('fq-model-visual--arriving');
    };
    modelPanel.appendChild(modelVisual);
    updateModelVisual($('.model-tab.active')?.dataset.model || 'b2b');
    $$('.model-tab').forEach((tab) => {
      tab.addEventListener('click', () => updateModelVisual(tab.dataset.model));
      tab.addEventListener('keydown', (event) => {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
          // script.js updates the selected tab; the change listener below follows keyboard activation.
          window.setTimeout(() => updateModelVisual($('.model-tab.active')?.dataset.model || 'b2b'), 0);
        }
      });
    });
  }

  // Scroll state is computed once per animation frame, so movement tracks sections smoothly.
  let rafPending = false;
  let activeScene = -1;
  const tones = [
    ['255, 135, 61', '88, 217, 232'],
    ['255, 167, 92', '99, 202, 232'],
    ['244, 112, 45', '105, 224, 216'],
    ['255, 146, 65', '103, 171, 245']
  ];
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const updateMotion = () => {
    rafPending = false;
    const scrollable = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    const scrollProgress = clamp(window.scrollY / scrollable, 0, 1);
    root.style.setProperty('--fq-progress', scrollProgress.toFixed(4));
    const header = $('.site-header');
    if (header) header.classList.toggle('is-scrolled', window.scrollY > 24);
    document.body.classList.add('fq-page-ready');

    let closestIndex = -1;
    let closestDistance = Infinity;
    const mid = window.innerHeight * .48;
    uniqueEditorialTargets.forEach((element) => {
      if (!element.classList.contains('fq-scroll-reveal') || element.classList.contains('is-visible')) return;
      const rect = element.getBoundingClientRect();
      if (rect.top < window.innerHeight + 150 && rect.bottom > -150) element.classList.add('is-visible');
    });

    scenes.forEach((scene, index) => {
      const rect = scene.getBoundingClientRect();
      const isVisible = rect.bottom > 0 && rect.top < window.innerHeight;
      scene.classList.toggle('is-in-view', isVisible);
      const local = clamp((window.innerHeight - rect.top) / (window.innerHeight + rect.height), 0, 1);
      const centre = rect.top + rect.height * .5;
      const distance = Math.abs(centre - mid);
      // The movement is applied only to decoration, never to form controls or reading text.
      const parallax = clamp((centre - mid) * -.055, -80, 80);
      const horizontal = Math.sin((index + 1) * .8 + scrollProgress * Math.PI * 2) * 28;
      scene.style.setProperty('--fq-progress-local', local.toFixed(3));
      scene.style.setProperty('--fq-shift-y', `${parallax.toFixed(1)}px`);
      scene.style.setProperty('--fq-shift-x', `${horizontal.toFixed(1)}px`);
      if (isVisible && distance < closestDistance) {
        closestDistance = distance;
        closestIndex = index;
      }
    });
    if (closestIndex !== -1 && closestIndex !== activeScene) {
      activeScene = closestIndex;
      document.body.dataset.fqActiveScene = String(closestIndex);
      const tone = tones[closestIndex % tones.length];
      root.style.setProperty('--fq-scene-warm', tone[0]);
      root.style.setProperty('--fq-scene-cool', tone[1]);
    }

    // Gentle vertical drift and tiny tilt keep the infinity trace coupled to scroll progress.
    const art = $('.fq-infinity-stage .fq-hero-infinity');
    if (art && !reduceMotion) {
      const parentRect = art.parentElement.getBoundingClientRect();
      const relative = clamp((window.innerHeight * .5 - (parentRect.top + parentRect.height * .5)) / Math.max(window.innerHeight, 1), -1, 1);
      art.style.setProperty('--fq-art-drift', `${(relative * 19).toFixed(1)}px`);
      art.style.setProperty('--fq-art-tilt', `${(relative * -1.4).toFixed(2)}deg`);
    }
  };
  const scheduleUpdate = () => {
    if (rafPending) return;
    rafPending = true;
    window.requestAnimationFrame(updateMotion);
  };
  window.addEventListener('scroll', scheduleUpdate, { passive: true });
  window.addEventListener('resize', scheduleUpdate, { passive: true });
  window.addEventListener('pageshow', scheduleUpdate, { passive: true });
  updateMotion();

  // Honor reduced-motion preferences if the user changes the OS setting mid-session.
  const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (motionQuery.addEventListener) {
    motionQuery.addEventListener('change', (event) => {
      if (event.matches) {
        $$('.fq-scroll-reveal').forEach((element) => element.classList.add('is-visible'));
        root.style.setProperty('--fq-progress', '0');
      }
    });
  }
})();
