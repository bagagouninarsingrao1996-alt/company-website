/* Frontiers Quantum — procedural 3D intelligence companion.
   No model files or image assets are required; the scene is assembled with Three.js. */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

(() => {
  'use strict';

  const stage = document.getElementById('fqRobotStage');
  const canvas = document.getElementById('fqRobotCanvas');
  if (!stage || !canvas) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let renderer;
  let animationFrame = 0;
  let visible = false;
  let destroyed = false;

  try {
    renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'low-power'
    });
  } catch (error) {
    console.warn('Frontiers Quantum 3D visual could not initialise; using the CSS fallback.', error);
    return;
  }

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 80);
  camera.position.set(0.25, 1.92, 6.55);
  camera.lookAt(0, 0.63, 0);

  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment(renderer);
  const environment = pmrem.fromScene(room, 0.04);
  scene.environment = environment.texture;
  scene.environmentIntensity = 0.82;
  pmrem.dispose();

  scene.add(new THREE.HemisphereLight(0xf4f7ff, 0x17243a, 1.05));

  const keyLight = new THREE.DirectionalLight(0xffeee0, 2.25);
  keyLight.position.set(-3.4, 5.3, 4.2);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.set(1024, 1024);
  keyLight.shadow.camera.near = 0.5;
  keyLight.shadow.camera.far = 12;
  keyLight.shadow.bias = -0.00035;
  keyLight.shadow.radius = 5;
  scene.add(keyLight);

  const rimLight = new THREE.DirectionalLight(0x74e5f0, 1.45);
  rimLight.position.set(3.8, 2.5, -3.3);
  scene.add(rimLight);

  const warmFill = new THREE.PointLight(0xff8b48, 2.1, 7);
  warmFill.position.set(-2.8, 1.2, 2.3);
  scene.add(warmFill);

  const coolFill = new THREE.PointLight(0x53d9e8, 1.25, 6);
  coolFill.position.set(2.8, 1.3, 1.0);
  scene.add(coolFill);

  const shell = new THREE.MeshPhysicalMaterial({
    color: 0xe9edf1,
    roughness: 0.34,
    metalness: 0.05,
    clearcoat: 0.72,
    clearcoatRoughness: 0.24
  });
  const shellLight = new THREE.MeshPhysicalMaterial({
    color: 0xf9faf9,
    roughness: 0.29,
    metalness: 0.035,
    clearcoat: 0.8,
    clearcoatRoughness: 0.2
  });
  const joint = new THREE.MeshStandardMaterial({ color: 0x192538, roughness: 0.48, metalness: 0.28 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x07101f, roughness: 0.3, metalness: 0.25 });
  const orange = new THREE.MeshStandardMaterial({
    color: 0xff8a43,
    emissive: 0xff5c1b,
    emissiveIntensity: 1.35,
    roughness: 0.32,
    metalness: 0.18
  });
  const cyan = new THREE.MeshStandardMaterial({
    color: 0x66e4ec,
    emissive: 0x21b8cc,
    emissiveIntensity: 1.2,
    roughness: 0.3,
    metalness: 0.15
  });
  const pedestalMaterial = new THREE.MeshStandardMaterial({ color: 0x111d31, roughness: 0.76, metalness: 0.2 });
  const screenMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x020710,
    roughness: 0.18,
    metalness: 0.18,
    clearcoat: 1,
    clearcoatRoughness: 0.09
  });

  const robot = new THREE.Group();
  robot.position.y = 0.04;
  scene.add(robot);

  function roundedBox(width, height, depth, radius, material, parent, position, rotation = [0, 0, 0]) {
    const geometry = new RoundedBoxGeometry(width, height, depth, 5, radius);
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(position[0], position[1], position[2]);
    mesh.rotation.set(rotation[0], rotation[1], rotation[2]);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function sphere(radius, material, parent, position, scale = [1, 1, 1]) {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 28, 20), material);
    mesh.position.set(position[0], position[1], position[2]);
    mesh.scale.set(scale[0], scale[1], scale[2]);
    mesh.castShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function tube(points, radius, material, parent, segments = 64) {
    const curve = new THREE.CatmullRomCurve3(points.map((point) => new THREE.Vector3(point[0], point[1], point[2])));
    const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, segments, radius, 8, false), material);
    mesh.castShadow = true;
    parent.add(mesh);
    return mesh;
  }

  // Circular technical pedestal with a thin illuminated upper rim.
  const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(0.78, 0.84, 0.18, 64), pedestalMaterial);
  pedestal.position.y = -0.58;
  pedestal.castShadow = true;
  pedestal.receiveShadow = true;
  robot.add(pedestal);

  const pedestalTop = new THREE.Mesh(
    new THREE.TorusGeometry(0.72, 0.018, 10, 96),
    new THREE.MeshStandardMaterial({ color: 0xff9853, emissive: 0xb74c1c, emissiveIntensity: 0.7, metalness: 0.45, roughness: 0.3 })
  );
  pedestalTop.rotation.x = Math.PI / 2;
  pedestalTop.position.y = -0.475;
  robot.add(pedestalTop);

  // Low-profile orbital rings sit behind the companion, reinforcing the FQ infinity / systems motif.
  const orbitalOrange = new THREE.MeshStandardMaterial({ color: 0xff9853, emissive: 0xa9441b, emissiveIntensity: 0.48, metalness: 0.5, roughness: 0.32 });
  const orbitalCyan = new THREE.MeshStandardMaterial({ color: 0x58d9e8, emissive: 0x167f94, emissiveIntensity: 0.5, metalness: 0.45, roughness: 0.3 });
  const orbitA = new THREE.Mesh(new THREE.TorusGeometry(1.08, 0.012, 10, 128), orbitalOrange);
  orbitA.position.set(0, 0.28, -0.22);
  orbitA.rotation.set(1.14, 0.12, -0.22);
  orbitA.scale.set(1.2, 0.7, 1);
  robot.add(orbitA);
  const orbitB = new THREE.Mesh(new THREE.TorusGeometry(1.17, 0.009, 8, 128), orbitalCyan);
  orbitB.position.set(0, 0.35, -0.28);
  orbitB.rotation.set(0.8, -0.28, 0.32);
  orbitB.scale.set(1.14, 0.63, 1);
  robot.add(orbitB);

  // Legs, feet and central body.
  sphere(0.18, joint, robot, [0, 0.15, 0]);
  roundedBox(0.29, 0.43, 0.31, 0.09, shell, robot, [-0.25, -0.1, 0], [0, 0, -0.035]);
  roundedBox(0.29, 0.43, 0.31, 0.09, shell, robot, [0.25, -0.1, 0], [0, 0, 0.035]);
  roundedBox(0.38, 0.17, 0.48, 0.07, shellLight, robot, [-0.25, -0.36, 0.08]);
  roundedBox(0.38, 0.17, 0.48, 0.07, shellLight, robot, [0.25, -0.36, 0.08]);
  roundedBox(0.55, 0.2, 0.58, 0.1, joint, robot, [0, 0.16, 0]);

  const torso = roundedBox(1.08, 0.98, 0.76, 0.18, shell, robot, [0, 0.69, 0]);
  roundedBox(0.78, 0.22, 0.06, 0.07, shellLight, robot, [0, 0.94, 0.405]);

  // Chest indicators and a small infinity insignia, drawn as a real 3D tube.
  sphere(0.035, orange, robot, [-0.16, 0.94, 0.447]);
  sphere(0.035, cyan, robot, [0, 0.94, 0.447]);
  sphere(0.035, orange, robot, [0.16, 0.94, 0.447]);
  const infinityPoints = [];
  for (let i = 0; i <= 84; i += 1) {
    const t = (i / 84) * Math.PI * 2;
    const denominator = 1 + Math.sin(t) * Math.sin(t);
    const x = 0.22 * Math.cos(t) / denominator;
    const y = 0.115 * Math.sin(t) * Math.cos(t) / denominator;
    infinityPoints.push([x, 0.66 + y, 0.455]);
  }
  tube(infinityPoints, 0.018, orange, robot, 100);
  sphere(0.018, cyan, robot, [0.22, 0.66, 0.465]);

  // Arms are segmented for a crafted, articulated silhouette.
  const shoulderLeft = sphere(0.16, joint, robot, [-0.59, 0.82, 0]);
  const shoulderRight = sphere(0.16, joint, robot, [0.59, 0.82, 0]);
  roundedBox(0.25, 0.42, 0.26, 0.09, shell, robot, [-0.72, 0.56, 0], [0, 0, -0.17]);
  roundedBox(0.25, 0.42, 0.26, 0.09, shell, robot, [0.72, 0.56, 0], [0, 0, 0.17]);
  sphere(0.105, joint, robot, [-0.76, 0.32, 0]);
  sphere(0.105, joint, robot, [0.76, 0.32, 0]);
  roundedBox(0.24, 0.4, 0.25, 0.08, shellLight, robot, [-0.78, 0.1, 0.02], [0, 0, -0.08]);
  roundedBox(0.24, 0.4, 0.25, 0.08, shellLight, robot, [0.78, 0.1, 0.02], [0, 0, 0.08]);
  roundedBox(0.25, 0.17, 0.27, 0.07, shellLight, robot, [-0.79, -0.17, 0.08]);
  roundedBox(0.25, 0.17, 0.27, 0.07, shellLight, robot, [0.79, -0.17, 0.08]);

  // Neck and head pivot: the head has a small idle tilt and pointer response.
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.16, 0.22, 32), joint);
  neck.position.set(0, 1.28, 0);
  neck.castShadow = true;
  robot.add(neck);

  const headPivot = new THREE.Group();
  headPivot.position.set(0, 1.82, 0);
  robot.add(headPivot);
  roundedBox(1.34, 1.05, 0.98, 0.2, shellLight, headPivot, [0, 0, 0]);

  // A dark glossy face, surrounded by a segmented orange/cyan light frame.
  roundedBox(0.91, 0.65, 0.095, 0.12, dark, headPivot, [0, 0.015, 0.51]);
  roundedBox(0.82, 0.56, 0.045, 0.09, screenMaterial, headPivot, [0, 0.015, 0.563]);
  roundedBox(0.95, 0.045, 0.052, 0.02, orange, headPivot, [0, 0.366, 0.568]);
  roundedBox(0.95, 0.045, 0.052, 0.02, cyan, headPivot, [0, -0.336, 0.568]);
  roundedBox(0.045, 0.66, 0.052, 0.02, cyan, headPivot, [-0.48, 0.015, 0.568]);
  roundedBox(0.045, 0.66, 0.052, 0.02, orange, headPivot, [0.48, 0.015, 0.568]);

  const eyeLeft = sphere(0.074, orange, headPivot, [-0.18, 0.025, 0.61], [0.83, 1.18, 0.48]);
  const eyeRight = sphere(0.074, cyan, headPivot, [0.18, 0.025, 0.61], [0.83, 1.18, 0.48]);
  eyeLeft.material = orange;
  eyeRight.material = cyan;

  // Ceramic side caps and subtle circuit bars on the head shell.
  [-1, 1].forEach((side) => {
    const ear = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.155, 0.14, 32), joint);
    ear.rotation.z = Math.PI / 2;
    ear.position.set(side * 0.71, -0.02, 0.02);
    ear.castShadow = true;
    headPivot.add(ear);
    const earLight = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.148, 32), side < 0 ? orange : cyan);
    earLight.rotation.z = Math.PI / 2;
    earLight.position.set(side * 0.72, -0.02, 0.02);
    headPivot.add(earLight);
  });

  const antennaStem = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.025, 0.14, 12), joint);
  antennaStem.position.set(-0.38, 0.58, -0.02);
  headPivot.add(antennaStem);
  sphere(0.045, cyan, headPivot, [-0.38, 0.66, -0.02]);

  // Rear cable loop, a small mechanical detail visible in profile.
  tube([
    [0.58, -0.12, -0.34], [0.78, -0.32, -0.4], [0.88, -0.55, -0.42],
    [0.79, -0.68, -0.4], [0.62, -0.62, -0.38]
  ], 0.027, joint, headPivot, 36);

  // Soft contact shadow plane. Its colour is transparent so the host section background remains visible.
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(5.5, 3.5),
    new THREE.ShadowMaterial({ color: 0x020610, opacity: 0.28 })
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = -0.49;
  shadowPlane.receiveShadow = true;
  robot.add(shadowPlane);

  const pointer = { x: 0, y: 0, targetX: 0, targetY: 0 };
  const onPointerMove = (event) => {
    if (reduceMotion) return;
    const bounds = stage.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    pointer.targetX = ((event.clientX - bounds.left) / bounds.width - 0.5) * 2;
    pointer.targetY = ((event.clientY - bounds.top) / bounds.height - 0.5) * 2;
  };
  const onPointerLeave = () => {
    pointer.targetX = 0;
    pointer.targetY = 0;
  };
  stage.addEventListener('pointermove', onPointerMove, { passive: true });
  stage.addEventListener('pointerleave', onPointerLeave, { passive: true });

  function resize() {
    const bounds = stage.getBoundingClientRect();
    const width = Math.max(1, Math.round(bounds.width));
    const height = Math.max(1, Math.round(bounds.height));
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.position.z = width < 520 ? 7.45 : width < 760 ? 6.95 : 6.55;
    camera.updateProjectionMatrix();
    renderer.render(scene, camera);
  }

  if ('ResizeObserver' in window) {
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(stage);
  } else {
    window.addEventListener('resize', resize, { passive: true });
  }
  resize();
  stage.classList.add('is-rendered');

  let lastBlink = 2.2;
  let nextBlink = 4.7;
  let blinkStart = -1;
  const clock = new THREE.Clock();
  const render = () => {
    animationFrame = 0;
    if (destroyed || !visible) return;
    const elapsed = clock.getElapsedTime();
    if (!reduceMotion) {
      pointer.x += (pointer.targetX - pointer.x) * 0.055;
      pointer.y += (pointer.targetY - pointer.y) * 0.055;
      robot.position.y = 0.04 + Math.sin(elapsed * 1.25) * 0.025;
      robot.rotation.y = Math.sin(elapsed * 0.35) * 0.045 + pointer.x * 0.12;
      headPivot.rotation.y = Math.sin(elapsed * 0.52) * 0.035 + pointer.x * 0.28;
      headPivot.rotation.x = Math.sin(elapsed * 0.82) * 0.018 + pointer.y * 0.08;
      headPivot.rotation.z = -0.035 + Math.sin(elapsed * 0.62) * 0.018 - pointer.x * 0.025;
      orbitA.rotation.z += 0.00055;
      orbitB.rotation.z -= 0.00038;

      if (elapsed > nextBlink && blinkStart < 0) {
        blinkStart = elapsed;
        lastBlink = elapsed;
        nextBlink = elapsed + 3.4 + Math.random() * 2.2;
      }
      if (blinkStart >= 0) {
        const blinkProgress = (elapsed - blinkStart) / 0.16;
        const squash = blinkProgress < 0.5 ? 1 - blinkProgress * 1.8 : Math.max(0.12, (blinkProgress - 0.5) * 1.8);
        eyeLeft.scale.y = 1.18 * Math.max(0.12, squash);
        eyeRight.scale.y = 1.18 * Math.max(0.12, squash);
        if (elapsed - blinkStart > 0.17) {
          blinkStart = -1;
          eyeLeft.scale.y = 1.18;
          eyeRight.scale.y = 1.18;
        }
      }
    }
    renderer.render(scene, camera);
    if (!reduceMotion) animationFrame = window.requestAnimationFrame(render);
  };

  const start = () => {
    if (visible || destroyed) return;
    visible = true;
    if (reduceMotion) {
      renderer.render(scene, camera);
    } else if (!animationFrame) {
      clock.start();
      animationFrame = window.requestAnimationFrame(render);
    }
  };
  const stop = () => {
    visible = false;
    if (animationFrame) {
      window.cancelAnimationFrame(animationFrame);
      animationFrame = 0;
    }
  };

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => (entry.isIntersecting ? start() : stop()));
    }, { threshold: 0.08, rootMargin: '100px 0px' });
    observer.observe(stage);
  } else {
    start();
  }

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else if (stage.getBoundingClientRect().bottom > 0 && stage.getBoundingClientRect().top < window.innerHeight) start();
  });

  window.addEventListener('pagehide', () => {
    destroyed = true;
    stop();
    stage.removeEventListener('pointermove', onPointerMove);
    stage.removeEventListener('pointerleave', onPointerLeave);
    renderer.dispose();
    environment.texture.dispose();
  }, { once: true });
})();
