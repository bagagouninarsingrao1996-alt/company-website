/*
 * Frontiers Quantum enquiry form configuration.
 * After deploying the Google Apps Script as a Web App, paste its /exec URL below.
 * Keep the complete URL including https://script.google.com/macros/s/.../exec
 */
window.FQ_GOOGLE_APPS_SCRIPT_URL = '';
